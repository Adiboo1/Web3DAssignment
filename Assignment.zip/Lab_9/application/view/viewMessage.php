<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Simple Message View</title>  
</head>
<body>
	<h1><?php echo $data ?> </h1>
</body>
</html>
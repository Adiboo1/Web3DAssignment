
[utopiafonts] 1999 free font
----------------------------------------------------

this font is provided free for personal or commercial use,
it can be redistributed however it may not be sold.  

HANDWRITING FONTS
-----------------
sorry people, but I have decided that I will no longer do free
handwriting fonts (as it is getting to be too big a task). I will
however consider doing a few free handwriting fonts a year, if
you can convince me. send gifts to:

			Dale Thorpe
			c/o BSSC
			P.O. BOX 454
			Bendigo, Victoria,
			Australia 3550

MAILING LIST
------------
join the utopiafonts mailing list by sending a blank email to:
subscribe-utopiafonts@egroups.com or just visit our webpage at:

http://utopiafonts.cjb.net/

----------------------------------------------------
� 1999 utopiafonts. dale_thorpe@bssc.edu.au